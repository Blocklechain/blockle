// nft.ts — WORLD Items: the item↔NFT bridge + a custodial NFT marketplace.
//
// Rare/equippable in-game items can be minted as BLOCK-721 NFTs (collection
// WITEM) to a player's custodial address, traded on a marketplace priced in
// WORLD, and redeemed back into in-game items. The on-chain BLOCK-721 tracks
// only ownership; this module keeps the tokenId→item mapping and the live
// listings off-chain. Marketplace settlement is custodial and instant: the WORLD
// price moves between the buyer's and seller's in-game balances (profile.block),
// while the NFT itself is escrowed in — and delivered from — the hot wallet
// (which is the collection's minter and the marketplace vault).
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import type { FastifyInstance, FastifyRequest } from "fastify";

import * as accounts from "./accounts.js";
import * as auth from "./auth.js";
import { loadProfile, touchProfile } from "./profiles.js";
import * as world from "./world.js";

const DATA_DIR = process.env.WORLD_DATA_DIR ?? join(process.cwd(), "data", "players");
const STORE = join(dirname(DATA_DIR), "witem.json");

interface TokenRec { item: string; owner: string; mintedAt: number; }
interface Listing { seller: string; sellerName: string; item: string; priceWorld: number; listedAt: number; }
interface Store {
  tokens: Record<string, TokenRec>;    // tokenIdHex -> item mapping + last-known owner
  listings: Record<string, Listing>;   // tokenIdHex -> active listing
  counter: number;                      // monotonic nonce for token ids
}

let store: Store = { tokens: {}, listings: {}, counter: 0 };
try { store = JSON.parse(readFileSync(STORE, "utf8")); } catch { /* first boot */ }
function save(): void {
  try { mkdirSync(dirname(STORE), { recursive: true }); writeFileSync(STORE, JSON.stringify(store, null, 0)); }
  catch (e) { console.error("[nft] store save failed", (e as Error).message); }
}

const COLLECTION = () => world.WITEM_CONTRACT;
function enabled(): boolean { return !!COLLECTION(); }

const minting = new Set<string>();  // tokenIds with an in-flight on-chain move

function sessionAddress(req: FastifyRequest): string | null {
  return auth.sessionAddress((req.headers as Record<string, unknown>)["x-world-token"]);
}
function custodialFor(acct: accounts.Account): world.Wallet {
  return { secret_hex: accounts.decryptSecret(acct), public_hex: acct.publicKey, address: acct.address };
}
function firstFreeSlot(inv: (string | null)[]): number {
  for (let i = 0; i < inv.length; i++) if (inv[i] == null) return i;
  return -1;
}

export function registerNft(api: FastifyInstance): void {
  // Collection metadata + how many items have been tokenised.
  api.get("/nft/collection", async () => ({
    enabled: enabled(),
    contract: COLLECTION(),
    name: "World Items",
    symbol: "WITEM",
    minted: Object.keys(store.tokens).length,
    listed: Object.keys(store.listings).length,
  }));

  // The caller's in-game inventory (so the web marketplace can offer to
  // tokenise items the player holds in the game).
  api.get("/nft/inventory", async (req, reply) => {
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const p = loadProfile(address, acct.name);
    const inv = p.inv.map((item, slot) => ({ slot, item })).filter((x) => x.item);
    return { inv, block: p.block };
  });

  // The caller's NFTs: ledger tokens whose last-known owner is this player's
  // custodial address, annotated with whether each is currently listed.
  api.get("/nft/mine", async (req, reply) => {
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const items = Object.entries(store.tokens)
      .filter(([id, t]) => t.owner === address && !store.listings[id])
      .map(([id, t]) => ({ tokenId: id, item: t.item, mintedAt: t.mintedAt }));
    return { items };
  });

  // Mint an in-game inventory item as an NFT to the player's custodial address.
  api.post("/nft/mint", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const { slot } = (req.body ?? {}) as { slot?: unknown };
    const s = Math.floor(Number(slot));
    const p = loadProfile(address, acct.name);
    if (!Number.isInteger(s) || s < 0 || s >= p.inv.length || !p.inv[s]) {
      return reply.code(400).send({ error: "no item in that inventory slot" });
    }
    const item = p.inv[s] as string;
    const tokenId = world.randomTokenId(`${address}:${s}:${item}:${store.counter++}:${Date.now()}`);
    if (store.tokens[tokenId]) return reply.code(409).send({ error: "token id collision, retry" });

    // remove the item from inventory up front; record the token so it shows as
    // pending, then mint on-chain in the background.
    p.inv[s] = null; touchProfile(address);
    store.tokens[tokenId] = { item, owner: address, mintedAt: Date.now() }; save();
    minting.add(tokenId);
    void (async () => {
      try {
        const txid = await world.mintNft(COLLECTION(), tokenId, address);
        console.log(`[nft] minted ${item} as ${tokenId.slice(0, 12)}… → ${address} (${txid})`);
      } catch (e) {
        // roll back: give the item back, drop the token record
        console.error("[nft] mint failed", (e as Error).message);
        const pp = loadProfile(address, acct.name);
        const free = firstFreeSlot(pp.inv);
        if (free >= 0) pp.inv[free] = item;
        touchProfile(address);
        delete store.tokens[tokenId]; save();
      } finally { minting.delete(tokenId); }
    })();
    return { status: "minting", tokenId, item };
  });

  // Redeem an NFT back into an in-game item: the player's custodial wallet
  // transfers it to the vault (gas sponsored), then the item returns to the bag.
  api.post("/nft/redeem", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const { tokenId } = (req.body ?? {}) as { tokenId?: unknown };
    const id = String(tokenId || "");
    const rec = store.tokens[id];
    if (!rec || rec.owner !== address) return reply.code(404).send({ error: "you don't own that item" });
    if (store.listings[id]) return reply.code(409).send({ error: "cancel the listing first" });
    if (minting.has(id)) return reply.code(409).send({ error: "item is busy" });
    const p = loadProfile(address, acct.name);
    if (firstFreeSlot(p.inv) < 0) return reply.code(400).send({ error: "inventory full" });

    minting.add(id);
    const vault = world.hotWallet().address;
    void (async () => {
      try {
        const cust = custodialFor(acct);
        await world.withGas(cust, () => world.transferNft(cust, COLLECTION(), id, vault));
        if (!(await world.waitNftOwner(COLLECTION(), id, world.addressTo32Hex(vault)))) {
          throw new Error("redeem transfer did not confirm");
        }
        const pp = loadProfile(address, acct.name);
        const free = firstFreeSlot(pp.inv);
        if (free >= 0) pp.inv[free] = rec.item;
        touchProfile(address);
        delete store.tokens[id]; save();
        console.log(`[nft] redeemed ${id.slice(0, 12)}… → item ${rec.item} for ${address}`);
      } catch (e) { console.error("[nft] redeem failed", (e as Error).message); }
      finally { minting.delete(id); }
    })();
    return { status: "redeeming", tokenId: id, item: rec.item };
  });

  // Withdraw an owned NFT to an external wallet (e.g. the player's own extension
  // wallet), so it shows up in self-custody. The game account's custodial wallet
  // signs the transfer (gas sponsored); the token leaves the game ledger.
  api.post("/nft/withdraw", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const { tokenId, to } = (req.body ?? {}) as { tokenId?: unknown; to?: unknown };
    const id = String(tokenId || "");
    const rec = store.tokens[id];
    if (!rec || rec.owner !== address) return reply.code(404).send({ error: "you don't own that item" });
    if (store.listings[id]) return reply.code(409).send({ error: "cancel the listing first" });
    if (!world.looksLikeBlockAddress(to)) return reply.code(400).send({ error: "invalid destination address" });
    if (minting.has(id)) return reply.code(409).send({ error: "item is busy" });
    minting.add(id);
    const dest = to as string;
    void (async () => {
      try {
        const cust = custodialFor(acct);
        await world.withGas(cust, () => world.transferNft(cust, COLLECTION(), id, dest));
        if (!(await world.waitNftOwner(COLLECTION(), id, world.addressTo32Hex(dest)))) {
          throw new Error("withdraw transfer did not confirm");
        }
        delete store.tokens[id]; save();
        console.log(`[nft] withdrew ${id.slice(0, 12)}… → ${dest}`);
      } catch (e) { console.error("[nft] withdraw failed", (e as Error).message); }
      finally { minting.delete(id); }
    })();
    return { status: "withdrawing", tokenId: id, to: dest };
  });

  // ---- marketplace --------------------------------------------------------
  api.get("/market/listings", async () => {
    const listings = Object.entries(store.listings).map(([id, l]) => ({
      tokenId: id, item: l.item, seller: l.sellerName, priceWorld: l.priceWorld, listedAt: l.listedAt,
    }));
    return { listings, currency: "WORLD" };
  });

  // List an owned NFT for sale: escrow it to the vault, then publish the listing.
  api.post("/market/list", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const { tokenId, price } = (req.body ?? {}) as { tokenId?: unknown; price?: unknown };
    const id = String(tokenId || "");
    const pr = Math.floor(Number(price));
    const rec = store.tokens[id];
    if (!rec || rec.owner !== address) return reply.code(404).send({ error: "you don't own that item" });
    if (store.listings[id]) return reply.code(409).send({ error: "already listed" });
    if (!Number.isFinite(pr) || pr <= 0) return reply.code(400).send({ error: "price must be a positive whole number of WORLD" });
    if (minting.has(id)) return reply.code(409).send({ error: "item is busy" });

    minting.add(id);
    const vault = world.hotWallet().address;
    const p = loadProfile(address, acct.name);
    void (async () => {
      try {
        const cust = custodialFor(acct);
        await world.withGas(cust, () => world.transferNft(cust, COLLECTION(), id, vault));
        if (!(await world.waitNftOwner(COLLECTION(), id, world.addressTo32Hex(vault)))) {
          throw new Error("escrow transfer did not confirm");
        }
        store.listings[id] = { seller: address, sellerName: p.name, item: rec.item, priceWorld: pr, listedAt: Date.now() };
        save();
        console.log(`[nft] listed ${id.slice(0, 12)}… (${rec.item}) for ${pr} WORLD by ${address}`);
      } catch (e) { console.error("[nft] list failed", (e as Error).message); }
      finally { minting.delete(id); }
    })();
    return { status: "listing", tokenId: id, priceWorld: pr };
  });

  // Buy a listed NFT: WORLD moves buyer→seller instantly in-game; the NFT is
  // delivered from the vault to the buyer's custodial address.
  api.post("/market/buy", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const { tokenId } = (req.body ?? {}) as { tokenId?: unknown };
    const id = String(tokenId || "");
    const l = store.listings[id];
    if (!l) return reply.code(404).send({ error: "not for sale" });
    if (l.seller === address) return reply.code(400).send({ error: "you are the seller" });
    if (minting.has(id)) return reply.code(409).send({ error: "item is busy" });
    const buyer = loadProfile(address, acct.name);
    if (buyer.block < l.priceWorld) return reply.code(400).send({ error: "not enough WORLD" });

    // settle the price in-game immediately (both ledgers), then deliver the NFT
    minting.add(id);
    buyer.block -= l.priceWorld; touchProfile(address);
    const sellerAcct = accounts.accountByAddress(l.seller);
    if (sellerAcct) { const sp = loadProfile(l.seller, sellerAcct.name); sp.block += l.priceWorld; touchProfile(l.seller); }
    const rec = store.tokens[id];
    delete store.listings[id];
    if (rec) { rec.owner = address; }
    save();
    void (async () => {
      try {
        const hot = world.hotWallet();
        await world.transferNft(hot, COLLECTION(), id, address);
        console.log(`[nft] sold ${id.slice(0, 12)}… (${l.item}) → ${address} for ${l.priceWorld} WORLD`);
      } catch (e) {
        // delivery failed: refund the buyer, restore the listing
        console.error("[nft] delivery failed, refunding", (e as Error).message);
        const bp = loadProfile(address, acct.name); bp.block += l.priceWorld; touchProfile(address);
        if (sellerAcct) { const sp = loadProfile(l.seller, sellerAcct.name); sp.block -= l.priceWorld; touchProfile(l.seller); }
        store.listings[id] = l; if (rec) rec.owner = l.seller; save();
      } finally { minting.delete(id); }
    })();
    return { status: "bought", tokenId: id, item: l.item, priceWorld: l.priceWorld };
  });

  // Cancel a listing: the vault returns the NFT to the seller.
  api.post("/market/cancel", async (req, reply) => {
    if (!enabled()) return reply.code(503).send({ error: "collection not configured" });
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const l = store.listings[String((req.body as any)?.tokenId || "")];
    const id = String((req.body as any)?.tokenId || "");
    if (!l || l.seller !== address) return reply.code(404).send({ error: "no such listing" });
    if (minting.has(id)) return reply.code(409).send({ error: "item is busy" });
    minting.add(id);
    delete store.listings[id];
    const rec = store.tokens[id]; if (rec) rec.owner = address;
    save();
    void (async () => {
      try { const hot = world.hotWallet(); await world.transferNft(hot, COLLECTION(), id, address); }
      catch (e) { console.error("[nft] cancel return failed", (e as Error).message); }
      finally { minting.delete(id); }
    })();
    return { status: "cancelled", tokenId: id };
  });
}
