// economy.ts — REST surface for the WORLD in-game currency: balance + deposit
// address, claim-a-deposit (sweep → credit), and withdraw (pool → external
// address). Mounted on the Fastify API in index.ts. All routes require a valid
// session (the same x-world-token used by /auth/me).
import type { FastifyInstance, FastifyRequest } from "fastify";

import * as accounts from "./accounts.js";
import * as auth from "./auth.js";
import { loadProfile, touchProfile } from "./profiles.js";
import * as world from "./world.js";

/** Addresses with an in-flight deposit sweep / withdrawal — guards against a
 *  second request kicking off a duplicate on-chain op before the first lands. */
const sweeping = new Set<string>();
const withdrawing = new Set<string>();

function sessionAddress(req: FastifyRequest): string | null {
  return auth.sessionAddress((req.headers as Record<string, unknown>)["x-world-token"]);
}

export function registerEconomy(api: FastifyInstance): void {
  // Balance + where to deposit. `pendingDepositBase` is WORLD already sitting at
  // the deposit address that hasn't been swept/credited yet.
  api.get("/economy/balance", async (req, reply) => {
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    const p = loadProfile(address, acct.name);
    let pending = "0";
    try { pending = (await world.worldBalanceBase(address)).toString(); } catch { /* node down */ }
    let pool = "0";
    try { pool = (await world.worldBalanceBase(world.hotWallet().address)).toString(); } catch { /* */ }
    return {
      currency: "WORLD",
      contract: world.WORLD_CONTRACT,
      decimals: world.WORLD_DECIMALS,
      balance: p.block, // whole WORLD, spendable in-game
      depositAddress: address, // the account's own custodial wallet
      pendingDepositBase: pending,
      sweeping: sweeping.has(address),
      poolBase: pool,
    };
  });

  // Claim a deposit: sweep whole-WORLD from the custodial wallet into the pool,
  // then credit the in-game balance. The sweep involves a gas top-up + a token
  // transfer, each of which must mine, so it runs in the background and the
  // client polls /economy/balance (sweeping:false + higher balance == done).
  api.post("/economy/deposit", async (req, reply) => {
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });
    if (sweeping.has(address)) return { status: "processing" };

    const base = await world.worldBalanceBase(address).catch(() => 0n);
    const whole = base / world.UNIT;
    if (whole <= 0n) {
      return { status: "empty", message: "Send at least 1 WORLD to your deposit address, then claim." };
    }

    sweeping.add(address);
    const custodial: world.Wallet = {
      secret_hex: accounts.decryptSecret(acct),
      public_hex: acct.publicKey,
      address: acct.address,
    };
    // fire-and-forget: credit once the sweep confirms on-chain
    void (async () => {
      try {
        const swept = await world.sweepWhole(custodial);
        if (swept > 0n) {
          const p = loadProfile(address, acct.name);
          p.block += Number(swept / world.UNIT);
          touchProfile(address);
          console.log(`[economy] deposit credited ${swept / world.UNIT} WORLD → ${address}`);
        }
      } catch (e) {
        console.error("[economy] deposit sweep failed for", address, (e as Error).message);
      } finally {
        sweeping.delete(address);
      }
    })();

    return { status: "processing", claimingWhole: whole.toString() };
  });

  // Withdraw whole WORLD to an external address, paid from the pool.
  api.post("/economy/withdraw", async (req, reply) => {
    const address = sessionAddress(req);
    if (!address) return reply.code(401).send({ error: "no session" });
    const acct = accounts.accountByAddress(address);
    if (!acct) return reply.code(404).send({ error: "no account" });

    const { to, amount } = (req.body ?? {}) as { to?: unknown; amount?: unknown };
    const amt = Math.floor(Number(amount));
    if (!Number.isFinite(amt) || amt <= 0) {
      return reply.code(400).send({ error: "amount must be a positive whole number of WORLD" });
    }
    if (!world.looksLikeBlockAddress(to)) {
      return reply.code(400).send({ error: "invalid destination address" });
    }
    if (withdrawing.has(address)) {
      return reply.code(409).send({ error: "a withdrawal is already in flight" });
    }

    const p = loadProfile(address, acct.name);
    if (p.block < amt) return reply.code(400).send({ error: "insufficient in-game balance" });

    const amountBase = BigInt(amt) * world.UNIT;
    const pool = await world.worldBalanceBase(world.hotWallet().address).catch(() => 0n);
    if (pool < amountBase) {
      return reply.code(503).send({ error: "withdrawals are temporarily unavailable while the pool is funded" });
    }

    withdrawing.add(address);
    p.block -= amt; // reserve immediately so the balance can't be double-spent
    touchProfile(address);
    try {
      const txid = await world.payWithdrawal(to as string, amountBase);
      return { status: "submitted", txid, amount: amt, to };
    } catch (e) {
      p.block += amt; // refund on failure
      touchProfile(address);
      return reply.code(502).send({ error: "withdrawal failed: " + (e as Error).message });
    } finally {
      withdrawing.delete(address);
    }
  });
}
