# WORLD economy + NFT server modules — ADD THESE TO THE GAME SOURCE

These three modules power WORLD-as-currency, the item↔NFT bridge, and the
marketplace API. They currently live ONLY on the box at
`/opt/world/app/apps/server/src/` and are **deleted every time you redeploy the
game from your dev machine** (your deploy replaces `src/` + reverts `index.ts`).
That wipe is what makes WORLD balance / NFTs / the marketplace stop working.

**Fix permanently:** commit these into your WORLD game repo under
`apps/server/src/`, and add the wiring below to `apps/server/src/index.ts`.

## Files (drop into apps/server/src/)
- `world.ts`    — chain primitives (bech32m decode, tokeninfo balance read,
                  WORLD transfer, pooled-custody deposit sweep + withdrawal,
                  BLOCK-721 mint/transfer/ownerOf). Needs @world/blockle-wasm-node.
- `economy.ts`  — REST: /economy/balance | deposit | withdraw.
- `nft.ts`      — REST: /nft/collection|inventory|mine|mint|redeem|withdraw +
                  /market/listings|list|buy|cancel. Ledger: data/witem.json.

## index.ts wiring (add these 4 things)
1. imports (next to the other `import * as auth …`):
       import { registerEconomy } from "./economy.js";
       import { registerNft } from "./nft.js";

2. CORS hook — right after `const api = Fastify({ logger: false });`:
       api.addHook("onRequest", async (req, reply) => {
         const origin = req.headers.origin;
         if (origin === "https://blockle.org" || origin === "https://www.blockle.org") {
           reply.header("access-control-allow-origin", origin);
           reply.header("vary", "Origin");
           reply.header("access-control-allow-methods", "GET,POST,OPTIONS");
           reply.header("access-control-allow-headers", "content-type,x-world-token");
           reply.header("access-control-max-age", "86400");
         }
         if (req.method === "OPTIONS") reply.code(204).send();
       });

3. registration — right before `await api.listen(...)`:
       registerEconomy(api);
       registerNft(api);

## Env (systemd already sets this on the box; keep it in your deploy)
    WITEM_CONTRACT=4a8234f9dda44e953f1a5d4877920431e7d991cdc4b718ff3315dcad7363be4e
    (optional) WORLD_HOT_WALLET=/var/lib/blockle-pool/wallet.json  (default)
    (optional) WORLD_CHAIN_API=http://127.0.0.1:8445              (default)

## Constants baked in
- WORLD token:      32a97972001bd895203c4bb5ac4645af02d81263438968ea32e35140f130d00f (8dp)
- World Items (NFT):4a8234f9dda44e953f1a5d4877920431e7d991cdc4b718ff3315dcad7363be4e
- Hot wallet / minter / vault = the node operator wallet (/var/lib/blockle-pool).
