// world.ts — WORLD (the on-chain BLOCK-20 token) as the in-game currency.
//
// Economic model: a single pooled *hot wallet* (the node operator wallet) holds
// every player's deposited WORLD and pays out withdrawals. Each account's own
// custodial wallet doubles as that player's unique deposit address; once WORLD
// lands there it is swept into the hot wallet (the hot wallet sponsors the tiny
// BLOCK gas for the sweep) and the player's in-game balance (profile.block) is
// credited. 1 in-game coin == 1 whole WORLD. Withdrawals are paid straight from
// the pool and are refused if the pool can't cover them, so the ledger can never
// pay out more WORLD than it actually custodies.
//
// WORLD contract: 32a97972…d00f (8 decimals, 1,000,000 fixed supply, launched
// into a BLOCK/WORLD AMM pool). BLOCK-20 selectors: 1 balanceOf(addr32),
// 2 transfer(to32‖amount_u64le). Balances are read via the node's `tokeninfo`
// convenience reader ({contract, holder}) which decodes block1 itself.
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const wasm = require("@world/blockle-wasm-node") as {
  build_call(
    secret_hex: string, public_hex: string, utxos_json: string,
    contract_hex: string, input_hex: string, value: bigint,
    gas_limit: bigint, gas_price: bigint,
  ): string;
  build_transfer(
    secret_hex: string, public_hex: string, utxos_json: string,
    to: string, amount: bigint, fee: bigint,
  ): string;
};

export const WORLD_CONTRACT =
  "32a97972001bd895203c4bb5ac4645af02d81263438968ea32e35140f130d00f";
export const WORLD_DECIMALS = 8;
/** base units in one whole WORLD */
export const UNIT = 100_000_000n;

const NODE = process.env.WORLD_CHAIN_API ?? "http://127.0.0.1:8445";
const HOT_WALLET_FILE =
  process.env.WORLD_HOT_WALLET ?? "/var/lib/blockle-pool/wallet.json";

const GAS_LIMIT = 200_000n;
const GAS_PRICE = 10n;
/** BLOCK sponsored to a custodial wallet so it can pay for a sweep's gas (0.05) */
const GAS_TOPUP = 5_000_000n;
/** native-transfer fee (0.001 BLOCK) */
const TX_FEE = 100_000n;

export interface Wallet {
  secret_hex: string;
  public_hex: string;
  address: string;
}

let _hot: Wallet | null = null;
export function hotWallet(): Wallet {
  if (!_hot) {
    const j = JSON.parse(readFileSync(HOT_WALLET_FILE, "utf8"));
    _hot = { secret_hex: j.secret_hex, public_hex: j.public_hex, address: j.address };
  }
  return _hot;
}

// ---- bech32m: block1… → 32-byte hex (with checksum verification) -----------
const CH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
function polymod(values: number[]): number {
  const G = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
  let chk = 1;
  for (const v of values) {
    const b = chk >>> 25;
    chk = ((chk & 0x1ffffff) << 5) ^ v;
    for (let i = 0; i < 5; i++) if ((b >> i) & 1) chk ^= G[i]!;
  }
  return chk >>> 0;
}
function hrpExpand(h: string): number[] {
  const o: number[] = [];
  for (let i = 0; i < h.length; i++) o.push(h.charCodeAt(i) >> 5);
  o.push(0);
  for (let i = 0; i < h.length; i++) o.push(h.charCodeAt(i) & 31);
  return o;
}
function convertBits(data: number[], from: number, to: number): number[] {
  let acc = 0, bits = 0;
  const out: number[] = [];
  const maxv = (1 << to) - 1;
  for (const v of data) {
    acc = (acc << from) | v;
    bits += from;
    while (bits >= to) { bits -= to; out.push((acc >> bits) & maxv); }
  }
  return out;
}
/** Decode a block1 bech32m address to its 32-byte payload (hex). Throws on any
 *  malformed address or bad checksum — withdrawals rely on this to never send
 *  WORLD to a mistyped destination. */
export function addressTo32Hex(addr: string): string {
  const pos = addr.lastIndexOf("1");
  if (pos < 1) throw new Error("bad address");
  const hrp = addr.slice(0, pos);
  const dp = addr.slice(pos + 1).toLowerCase();
  const data: number[] = [];
  for (const c of dp) {
    const v = CH.indexOf(c);
    if (v < 0) throw new Error("bad address char");
    data.push(v);
  }
  if (polymod(hrpExpand(hrp).concat(data)) !== 0x2bc830a3) {
    throw new Error("bad address checksum");
  }
  const bytes = convertBits(data.slice(0, -6), 5, 8);
  if (bytes.length !== 32) throw new Error("address is not 32 bytes");
  return bytes.map((x) => x.toString(16).padStart(2, "0")).join("");
}
export function looksLikeBlockAddress(a: unknown): a is string {
  if (typeof a !== "string" || !a.startsWith("block1")) return false;
  try { addressTo32Hex(a); return true; } catch { return false; }
}

function u64le(n: bigint): string {
  const b = Buffer.alloc(8);
  b.writeBigUInt64LE(n);
  return b.toString("hex");
}

// ---- node RPC --------------------------------------------------------------
async function rpc(method: string, params: unknown[]): Promise<any> {
  const r = await fetch(NODE, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "1.0", id: "world", method, params }),
  });
  const b = await r.json().catch(() => ({}));
  if (b && b.error) throw new Error(`${method}: ${JSON.stringify(b.error)}`);
  return b.result != null ? b.result : b;
}
async function get(path: string): Promise<any> {
  const r = await fetch(NODE + path, { headers: { accept: "application/json" } });
  if (!r.ok) throw new Error(`GET ${path} ${r.status}`);
  return r.json();
}

/** WORLD balance (base units) held by an address. */
export async function worldBalanceBase(addr: string): Promise<bigint> {
  const r = await rpc("tokeninfo", [{ contract: WORLD_CONTRACT, holder: addr }]);
  return BigInt(r.balance ?? 0);
}

async function blockUtxos(
  addr: string,
): Promise<{ utxos: { txid: string; vout: number; amount: number }[]; spendable: number }> {
  const u = await get("/explorer/utxos/" + encodeURIComponent(addr));
  return {
    utxos: (u.utxos || []).map((x: any) => ({ txid: x.txid, vout: x.vout, amount: Number(x.amount) })),
    spendable: Number(u.spendable || 0),
  };
}
function utxoSig(utxos: { txid: string; vout: number }[]): string {
  return utxos.map((x) => x.txid + ":" + x.vout).sort().join(",");
}

async function submit(raw: string): Promise<void> {
  await rpc("submitrawtransaction", [raw]);
}
function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Wait until an address's confirmed UTXO set changes (its prior tx mined). */
async function waitBlockChange(addr: string, prevSig: string, ms = 900_000): Promise<boolean> {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    await sleep(6000);
    const u = await blockUtxos(addr).catch(() => null);
    if (u && utxoSig(u.utxos) !== prevSig) return true;
  }
  return false;
}
/** Wait until an address holds at least `targetBase` WORLD. */
async function waitWorldAtLeast(addr: string, targetBase: bigint, ms = 900_000): Promise<boolean> {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    const b = await worldBalanceBase(addr).catch(() => null);
    if (b != null && b >= targetBase) return true;
    await sleep(6000);
  }
  return false;
}

// ---- transfers -------------------------------------------------------------
/** Native BLOCK transfer. */
async function sendBlock(from: Wallet, to: string, amountBase: bigint): Promise<string> {
  const { utxos } = await blockUtxos(from.address);
  const built = JSON.parse(
    wasm.build_transfer(from.secret_hex, from.public_hex, JSON.stringify(utxos), to, amountBase, TX_FEE),
  );
  if (!built.raw) throw new Error("build_transfer produced no tx");
  await submit(built.raw);
  return built.txid;
}
/** WORLD (BLOCK-20) transfer: selector 2, calldata = to(32) ‖ amount_u64le(8). */
async function sendWorld(from: Wallet, to: string, amountBase: bigint): Promise<string> {
  const input = "02" + addressTo32Hex(to) + u64le(amountBase);
  const { utxos } = await blockUtxos(from.address);
  const built = JSON.parse(
    wasm.build_call(from.secret_hex, from.public_hex, JSON.stringify(utxos), WORLD_CONTRACT, input, 0n, GAS_LIMIT, GAS_PRICE),
  );
  if (!built.raw) throw new Error("build_call produced no tx");
  await submit(built.raw);
  return built.txid;
}

/** Pay a withdrawal of `amountBase` WORLD from the pooled hot wallet. Refuses if
 *  the pool can't cover it (keeps the ledger solvent). Returns the txid. */
export async function payWithdrawal(to: string, amountBase: bigint): Promise<string> {
  if (!looksLikeBlockAddress(to)) throw new Error("invalid destination address");
  const hot = hotWallet();
  const pool = await worldBalanceBase(hot.address);
  if (pool < amountBase) throw new Error("pool cannot cover this withdrawal");
  return sendWorld(hot, to, amountBase);
}

/** Sweep the whole-WORLD balance of a custodial wallet into the pool. Tops up
 *  the custodial wallet's gas from the hot wallet first if needed, waits for
 *  each step to confirm, and returns the base amount actually swept (0 if the
 *  custodial wallet held less than 1 WORLD). */
export async function sweepWhole(custodial: Wallet): Promise<bigint> {
  const hot = hotWallet();
  const base = await worldBalanceBase(custodial.address);
  const whole = (base / UNIT) * UNIT; // only whole WORLD; dust stays for next time
  if (whole <= 0n) return 0n;

  const { spendable, utxos } = await blockUtxos(custodial.address);
  if (BigInt(spendable) < GAS_TOPUP) {
    const sig0 = utxoSig(utxos);
    await sendBlock(hot, custodial.address, GAS_TOPUP);
    if (!(await waitBlockChange(custodial.address, sig0))) {
      throw new Error("gas top-up did not confirm");
    }
  }
  const poolBefore = await worldBalanceBase(hot.address);
  await sendWorld(custodial, hot.address, whole);
  if (!(await waitWorldAtLeast(hot.address, poolBefore + whole))) {
    throw new Error("sweep did not confirm");
  }
  return whole;
}

// ===========================================================================
// WORLD Items — the game's BLOCK-721 NFT collection
// ---------------------------------------------------------------------------
// The collection is deployed by the hot wallet, which is therefore its sole
// authorized minter. Rare/equippable in-game items are minted as NFTs to a
// player's custodial address; the item↔tokenId mapping is kept off-chain by the
// game (the on-chain BLOCK-721 only tracks ownership). BLOCK-721 selectors:
//   1 balanceOf(owner:32) · 2 transfer(id:32 ‖ to:32) · 7 ownerOf(id:32) · 8 mint(id:32 ‖ to:32)
// The collection contract id is injected via WITEM_CONTRACT once deployed.
export const WITEM_CONTRACT = process.env.WITEM_CONTRACT ?? "";

/** Owner (32-byte hex) of an NFT, or null if unminted / call failed. */
export async function nftOwnerOf(collection: string, tokenIdHex: string): Promise<string | null> {
  const r = await rpc("callcontract", [{ contract: collection, calldata: "07" + tokenIdHex }]);
  if (!r.success || !r.returnHex) return null;
  return String(r.returnHex).toLowerCase();
}
/** How many NFTs an address holds in a collection. */
export async function nftBalanceOf(collection: string, addr: string): Promise<bigint> {
  const r = await rpc("callcontract", [{ contract: collection, calldata: "01" + addressTo32Hex(addr) }]);
  return r.u64 != null ? BigInt(r.u64) : 0n;
}
/** Mint `tokenId` to `to` (hot wallet must be the collection's minter). */
export async function mintNft(collection: string, tokenIdHex: string, to: string): Promise<string> {
  const hot = hotWallet();
  const input = "08" + tokenIdHex + addressTo32Hex(to);
  const { utxos } = await blockUtxos(hot.address);
  const built = JSON.parse(
    wasm.build_call(hot.secret_hex, hot.public_hex, JSON.stringify(utxos), collection, input, 0n, GAS_LIMIT, GAS_PRICE),
  );
  if (!built.raw) throw new Error("mint build_call produced no tx");
  await submit(built.raw);
  return built.txid;
}
/** Transfer NFT `tokenId` from a wallet it owns to `to`. */
export async function transferNft(from: Wallet, collection: string, tokenIdHex: string, to: string): Promise<string> {
  const input = "02" + tokenIdHex + addressTo32Hex(to);
  const { utxos } = await blockUtxos(from.address);
  const built = JSON.parse(
    wasm.build_call(from.secret_hex, from.public_hex, JSON.stringify(utxos), collection, input, 0n, GAS_LIMIT, GAS_PRICE),
  );
  if (!built.raw) throw new Error("nft transfer build_call produced no tx");
  await submit(built.raw);
  return built.txid;
}
/** Ensure a custodial wallet has gas (sponsored by the hot wallet), then run
 *  `op` which signs a tx from it. Used for player-signed NFT moves (escrow). */
export async function withGas(custodial: Wallet, op: () => Promise<string>): Promise<string> {
  const hot = hotWallet();
  const { spendable, utxos } = await blockUtxos(custodial.address);
  if (BigInt(spendable) < GAS_TOPUP) {
    const sig0 = utxoSig(utxos);
    await sendBlock(hot, custodial.address, GAS_TOPUP);
    if (!(await waitBlockChange(custodial.address, sig0))) throw new Error("gas top-up did not confirm");
  }
  return op();
}
/** Wait until an NFT's on-chain owner becomes `expected32hex` (a transfer mined). */
export async function waitNftOwner(collection: string, tokenIdHex: string, expected32hex: string, ms = 900_000): Promise<boolean> {
  const want = expected32hex.toLowerCase();
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    const o = await nftOwnerOf(collection, tokenIdHex).catch(() => null);
    if (o && o === want) return true;
    await sleep(6000);
  }
  return false;
}
/** 32 random bytes (hex) for a fresh token id. Deterministic entropy source is
 *  the caller's responsibility; pass a seed to avoid Math.random in restricted
 *  contexts. */
export function randomTokenId(seedHex: string): string {
  // mix a caller seed with a per-call hash via the wasm-free path: fold the seed
  return require("node:crypto").createHash("sha256").update(seedHex).digest("hex");
}
